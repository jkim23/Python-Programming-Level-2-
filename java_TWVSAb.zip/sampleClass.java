// JT KIM
// MOD 7 PROBLEM 1
// 5 - 21 - 2019 


  public class sampleClass {
  int x = 2;

  public static void main(String[] args) {
    sampleClass myObj = new sampleClass();
    
myObj.x = 15;
    
System.out.println(myObj.x);
    
sampleClass myObj2 = new sampleClass();
System.out.println(myObj2.x);
    
    
  }
}
