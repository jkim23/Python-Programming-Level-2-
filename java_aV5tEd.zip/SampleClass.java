//J.T. Kim
// Mod 6 Problem 2
//Create a class called “sampleClass” with an interger variable x.

public class SampleClass
{
  int x = 5;
  
  public static void main(String []args)
  {
    
    SampleClass SampleObj = new SampleClass();
    
    System.out.println(SampleObj.x);
  }
}