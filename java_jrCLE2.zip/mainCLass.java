// JT KIM
// Mod 9
// June 4th 2019

// Extends the following code sample by adding a subclass for cats and another for dogs.
// Extends Problem 1 by adding a main class that creates objects for each animal subclass and calls that objects animalSound() method.




class Animal {
  public void animalSound() {
    System.out.println("The animal makes a sound");
  }
}

class Pig extends Animal {
  public void animalSound() {
    System.out.println("The pig says: wee wee");
  }
}

class Cat extends Animal {
  public void animalSound() {
    System.out.println("The cat says: meow meow");
  }
}

class Dog extends Animal {
  public void animalSound() {
    System.out.println("The dog says: ruff ruff");
  }
}

public class mainCLass
{
  public static void main(String [] args)
  {
    Animal pigObj = new Pig();
    Animal catObj = new Cat();
    Animal dogObj = new Dog();
    
    pigObj.animalSound();
    catObj.animalSound();
    dogObj.animalSound();
    
  }
}