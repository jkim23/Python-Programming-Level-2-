// J.T. Kim
//Module 5 Problem 4
//Create and print an example using each of the following arithmetic operators: +, -, *, /, %, ++, and --.

public class M5P4
{
  public static void main(String []args)
  {  
    int x = 10;
    int y = 5; 
    int test1;
    
    test1 = x + y;
    System.out.println(test1);
    System.out.println(x + y);
    
  
     x = 13;
     y = 2; 
    int test2;
    
    test2 = x - y;
    System.out.println(test2);
    System.out.println(x - y);
    
     x = 10;
     y = 5; 
    int test3;
    
    test3 = x * y;
    System.out.println(test3);
    System.out.println(x * y);
    
     x = 10;
     y = 5; 
    int test4;
    
    test4 = x / y;
    System.out.println(test4);
    System.out.println(x / y);
    
     x = 10;
     y = 5; 
    int test5;
    
    test5 = x % y;
    System.out.println(test5);
    System.out.println(x % y);
    
     x = 1;
     
    int test6;
    
     x ++;
 
    System.out.println(x);
    
     x = 1;
     
    int test7;
    
     x --;
 
    System.out.println(x);
    
  }
}  