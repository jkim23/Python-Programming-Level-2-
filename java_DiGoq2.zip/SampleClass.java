//J.T. Kim
// Mod 6 Problem 1
//Create a class called “sampleClass” with an interger variable x.

public class SampleClass
{
  int x = 5;
  
  public static void main(String []args)
  {
    
    SampleClass myObj = new SampleClass();
    
    System.out.println(myObj.x);
  }
}