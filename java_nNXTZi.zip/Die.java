// JT KIM
// MOD 7 PROBLEM 4
// 5 - 21 - 2019 


public class Die
{
   private int lastValue;

   public int roll()
   {
      lastValue = (int) (Math.random() * 6) + 1;
      return lastValue;
   }

   public static void main(String[] args)
   {
     int intArray[]=new int[10];
      Die d = new Die();
      for (int i = 0; i < 10; i++)
      {
        intArray[i]=d.roll();
       System.out.println("Roll "+ (i+1) + " is "+intArray[i]);
         System.out.println(d.roll());
      }
   }
 }
