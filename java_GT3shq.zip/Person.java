// jt kim
// mod 8 lab activity 


public class Person
{
  private String name;
  
 public String getName()
 {
       return name; 
   
 }
  
 public void setName(String newName)
 {
   		name = newName;
  
 }

public static void main(String[] args)
{
  Person JT = new Person();
  JT.setName("JT");
  
  JT.getName();
  
 System.out.println(JT.getName());
}
}


